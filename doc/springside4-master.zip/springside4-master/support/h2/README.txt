Command to open a H2 web console.

If the maven script is not work, get the h2 jar file and type below command:

java -jar h2-1.3.168.jar -web -webPort 8090 -browser