Exported Sonar profile.

springside-*.xml is a springside version base on sonar default profle.

please see the wiki: https://github.com/springside/springside4/wiki/Sonar