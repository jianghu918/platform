#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
delete from ${tablePrefix}task;
delete from ${tablePrefix}user;